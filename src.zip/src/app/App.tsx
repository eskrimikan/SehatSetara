import { useState, useEffect, useRef } from "react";
import { Home, BookOpen, MapPin, Activity, Mic, Stethoscope } from "lucide-react";
import HomeScreen, { type Screen } from "./components/HomeScreen";
import MedicalInfoScreen from "./components/MedicalInfoScreen";
import FaskesScreen from "./components/FaskesScreen";
import LifestyleScreen from "./components/LifestyleScreen";
import VoiceQAScreen from "./components/VoiceQAScreen";

type MedTab = "penyakit" | "p3k" | "obat";

const navItems: { id: Screen; icon: typeof Home; label: string }[] = [
  { id: "home",      icon: Home,     label: "Beranda"   },
  { id: "medical",   icon: BookOpen, label: "Info"      },
  { id: "faskes",    icon: MapPin,   label: "Faskes"    },
  { id: "lifestyle", icon: Activity, label: "Lifestyle" },
  { id: "qa",        icon: Mic,      label: "Tanya"     },
];

const OUTER_PAD = "20px 20px";

export default function App() {
  const [screen, setScreen] = useState<Screen>("home");
  const [medTab, setMedTab] = useState<MedTab>("penyakit");
  const [qaQuery, setQaQuery] = useState<string>(""); // State penampung data chat dari Home
  const [scrollY, setScrollY] = useState(0);
  const mainRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = mainRef.current;
    if (!el) return;
    const handler = () => setScrollY(el.scrollTop);
    el.addEventListener("scroll", handler, { passive: true });
    return () => el.removeEventListener("scroll", handler);
  }, []);

  useEffect(() => {
    if (mainRef.current) mainRef.current.scrollTop = 0;
    setScrollY(0);
  }, [screen]);

  const navigate = (s: Screen, payload?: string) => {
    setScreen(s);
    if (s === "medical" && payload) setMedTab(payload as MedTab);
    if (s === "qa" && payload) setQaQuery(payload); // Menangkap pesan dari Home
  };

  // 0 = transparent glass (over hero), 1 = solid gradient
  const progress = screen === "home" ? Math.min(scrollY / 180, 1) : 1;

  const innerBg = progress < 0.05
    ? "rgba(255,255,255,0.10)"
    : `rgba(78,106,240,${0.55 + 0.45 * progress})`;

  const innerShadow = progress < 0.1
    ? `inset 0 0 0 1px rgba(255,255,255,${0.22 * (1 - progress)})`
    : `0 4px 28px rgba(91,116,245,${0.28 * progress})`;

  return (
    <div className="size-full flex flex-col bg-white">
      {/* ── Fixed floating pill navbar ── */}
      <header
        className="fixed top-0 left-0 right-0 z-50"
        style={{ padding: OUTER_PAD, pointerEvents: "none" }}
      >
        <div
          className="flex items-center h-12"
          style={{
            background: innerBg,
            backdropFilter: "blur(20px)",
            WebkitBackdropFilter: "blur(20px)",
            borderRadius: "9999px",
            boxShadow: innerShadow,
            border: progress < 0.1 ? "1px solid rgba(255,255,255,0.18)" : "none",
            transition: "background 0.35s ease, box-shadow 0.35s ease, border 0.35s ease",
            padding: "0 8px 0 20px",
            pointerEvents: "auto",
          }}
        >
          {/* Logo — left */}
          <div className="flex items-center gap-2 flex-shrink-0">
            <div className="w-7 h-7 bg-white/20 rounded-full flex items-center justify-center">
              <Stethoscope size={15} className="text-white" />
            </div>
            <span className="text-white font-bold text-sm tracking-tight">SehatSetara</span>
          </div>

          {/* Spacer */}
          <div className="flex-1" />

          {/* Nav tabs — right */}
          <nav className="flex items-center gap-0.5">
            {navItems.map(({ id, label }) => {
              const active = screen === id;
              return (
                <button
                  key={id}
                  onClick={() => navigate(id)}
                  className={`px-4 py-1.5 rounded-full text-sm font-medium transition-all ${
                    active
                      ? "text-[#5b74f5] shadow-md"
                      : "text-white/80 hover:text-white hover:bg-white/15"
                  }`}
                  style={active ? { background: "linear-gradient(135deg, #ffffff 0%, #dbeafe 100%)" } : {}}
                >
                  {label}
                </button>
              );
            })}
          </nav>
        </div>
      </header>

      {/* ── Screen content ── */}
      <main ref={mainRef} className="flex-1 overflow-y-auto min-h-0">
        {screen === "home" && <HomeScreen onNavigate={navigate} />}
        {screen !== "home" && (
          <div className="h-full flex flex-col pt-16">
            {screen === "medical"   && <MedicalInfoScreen initialTab={medTab} />}
            {screen === "faskes"    && <FaskesScreen />}
            {screen === "lifestyle" && <LifestyleScreen />}
            {screen === "qa"        && <VoiceQAScreen initialQuery={qaQuery} clearQuery={() => setQaQuery("")} />}
          </div>
        )}
      </main>
    </div>
  );
}