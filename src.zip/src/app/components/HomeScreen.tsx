import { useState, useRef } from "react";
import {
  AlertCircle, MapPin, Activity, Mic, ChevronRight, Sun,
  Heart, ClipboardList, Bandage, Pill, Building2,
  Leaf, Droplets, Moon, Flame, Shield, Send,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import heroImg from "../../imports/image-5.png";

export type Screen = "home" | "medical" | "faskes" | "lifestyle" | "qa";

interface Props {
  onNavigate: (screen: Screen, tab?: string) => void;
}

interface HealthTip {
  icon: LucideIcon;
  title: string;
  desc: string;
}

const healthTips: HealthTip[] = [
  { icon: Droplets, title: "Cuci Tangan 6 Langkah",          desc: "Cuci tangan dengan sabun minimal 20 detik dapat mencegah 80% penyakit menular umum." },
  { icon: Droplets, title: "Minum 8 Gelas Air Sehari",        desc: "Konsumsi 2 liter air putih per hari menjaga fungsi ginjal, kulit, dan konsentrasi Anda." },
  { icon: Leaf,     title: "Makan Sayur & Buah Setiap Hari",  desc: "Setengah piring sayur dan buah memenuhi kebutuhan vitamin, mineral, dan serat harian." },
  { icon: Moon,     title: "Tidur 7–8 Jam Per Malam",         desc: "Tidur cukup meningkatkan imunitas dan membantu tubuh memperbaiki sel-sel yang rusak." },
  { icon: Activity, title: "Aktif Bergerak 30 Menit",          desc: "Jalan kaki 30 menit per hari menurunkan risiko penyakit jantung, diabetes, dan depresi." },
];

const todayTip = healthTips[new Date().getDay() % healthTips.length];

const emergencyNumbers = [
  { name: "Ambulans / IGD",   number: "119", icon: AlertCircle, color: "bg-[#fff0f0] border-[#ffd5d5]", text: "text-[#f84848]" },
  { name: "Pemadam Kebakaran", number: "113", icon: Flame,       color: "bg-[#fff4ec] border-[#ffe0cc]", text: "text-orange-500" },
  { name: "Polisi",            number: "110", icon: Shield,      color: "bg-[#edf2fd] border-[#c8d8fb]", text: "text-[#5b74f5]" },
];

const quickActions = [
  { screen: "medical"   as Screen, tab: "penyakit", icon: ClipboardList, label: "Info Penyakit",       sublabel: "10+ panduan lengkap"   },
  { screen: "medical"   as Screen, tab: "p3k",      icon: Bandage,       label: "Pertolongan Pertama", sublabel: "Panduan darurat cepat"  },
  { screen: "faskes"    as Screen, tab: undefined,  icon: MapPin,        label: "Faskes Terdekat",     sublabel: "Peta & kontak"          },
  { screen: "lifestyle" as Screen, tab: undefined,  icon: Leaf,          label: "Gaya Hidup",          sublabel: "Lacak kebiasaanmu"      },
];

const stats = [
  { label: "Penyakit terdokumentasi", value: "10+", sub: "Info lengkap offline",        icon: ClipboardList },
  { label: "Panduan P3K",             value: "8",   sub: "Langkah-langkah terstruktur", icon: Bandage       },
  { label: "Obat-obatan",             value: "10",  sub: "Dosis & peringatan lengkap",  icon: Pill          },
  { label: "Faskes terdekat",         value: "7",   sub: "Peta & kontak darurat",        icon: Building2     },
];

export default function HomeScreen({ onNavigate }: Props) {
  const [chatInput, setChatInput] = useState("");
  const [isListening, setIsListening] = useState(false);
  const recogRef = useRef<any>(null);

  const now     = new Date();
  const hour    = now.getHours();
  const greeting = hour < 12 ? "Selamat Pagi" : hour < 17 ? "Selamat Siang" : "Selamat Malam";
  const dayName  = now.toLocaleDateString("id-ID", { weekday: "long", day: "numeric", month: "long", year: "numeric" });
  const TipIcon  = todayTip.icon;

  const submitChat = () => {
    if (chatInput.trim()) {
      onNavigate("qa", chatInput.trim());
      setChatInput("");
    } else {
      onNavigate("qa");
    }
  };

  const startVoice = () => {
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SR) { 
      alert("Browser Anda tidak mendukung fitur pengenalan suara. Gunakan Chrome atau Safari terbaru."); 
      return; 
    }
    
    if (isListening) { 
      recogRef.current?.stop(); 
      setIsListening(false); 
      return; 
    }

    const r = new SR(); 
    r.lang = "id-ID"; 
    r.continuous = false; 
    r.interimResults = false;
    
    r.onstart = () => setIsListening(true);
    r.onresult = (e: any) => { 
      const transcript = e.results[0][0].transcript; 
      setChatInput(transcript); 
    };
    r.onend = () => setIsListening(false);
    r.onerror = () => setIsListening(false);
    
    r.start();
    recogRef.current = r;
  };

  return (
    <div className="min-h-full">
      {/* CSS Animasi Melayang */}
      <style>{`
        @keyframes float-slow {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-15px); }
        }
        @keyframes float-delay {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-12px); }
        }
        .animate-float-1 { animation: float-slow 4s ease-in-out infinite; }
        .animate-float-2 { animation: float-delay 5s ease-in-out infinite; animation-delay: 2s; }
      `}</style>

      {/* ── Hero ── */}
      <div className="w-full pt-4 px-4 pb-4 box-border h-[751px]">
        <div className="relative w-full h-[725px] rounded-3xl overflow-hidden flex items-center justify-center">
          <img src={heroImg} alt=""
            className="absolute inset-0 w-full h-full object-cover object-center" />

          {/* Bottom blue gradient overlay */}
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#edf2fd80] via-50% to-[#5b74f5]" />

          {/* === BUBBLE CHAT SVG PUTIH POLOS + NAIK 2PX === */}
          
          {/* Bubble 1: Kiri, ikon Hati (Ukurannya Dikecilin Biar Proporsional) */}
          <div className="absolute top-[22%] left-[12%] animate-float-1 z-10 hidden sm:block">
             {/* Pendaran (Glow) */}
             <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 bg-white/20 blur-3xl rounded-full" />
             
             {/* Lingkaran Transparan di belakang */}
             <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-[calc(50%+2px)] w-[110px] h-[110px] bg-white/10 border border-white/20 rounded-full backdrop-blur-md" />
             
             {/* Wrapper SVG dikecilin jadi w-[80px] h-[84px] */}
             <div className="relative z-10 w-[80px] h-[84px] flex items-center justify-center" style={{ filter: 'drop-shadow(0 10px 15px rgba(0,0,0,0.12))' }}>
               <svg className="absolute inset-0 w-full h-full -scale-x-100" viewBox="0 0 100 104" fill="none" xmlns="http://www.w3.org/2000/svg">
                 <path d="M50 0C77.6142 0 100 22.3858 100 50C100 61.3433 96.2208 71.8028 89.8551 80.1921C88.7019 81.7119 88 83.5416 88 85.4493V101.063C88 102.474 86.5797 103.441 85.2675 102.924L71.6374 97.5595C69.7337 96.8102 67.6244 96.8462 65.6818 97.4878C60.7495 99.1166 55.4781 100 50 100C22.3858 100 0 77.6142 0 50C0 22.3858 22.3858 0 50 0Z" fill="#ffffff"/>
               </svg>
               {/* Ikon Heart dikecilin ukurannya jadi 32 biar pas di tengah SVG */}
               <Heart size={32} className="text-[#f84848] relative z-20 mb-1" />
             </div>
          </div>

          {/* Bubble 2: Kanan, ikon Obat */}
          <div className="absolute top-[48%] right-[12%] animate-float-2 z-10 hidden sm:block">
             {/* Pendaran (Glow) */}
             <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-56 h-56 bg-white/15 blur-3xl rounded-full" />
             
             {/* Lingkaran Transparan di belakang */}
             <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-[calc(50%+2px)] w-[130px] h-[130px] bg-white/10 border border-white/20 rounded-full backdrop-blur-md" />
             
             <div className="relative z-10 w-[100px] h-[104px] flex items-center justify-center" style={{ filter: 'drop-shadow(0 12px 20px rgba(0,0,0,0.15))' }}>
               <svg className="absolute inset-0 w-full h-full" viewBox="0 0 100 104" fill="none" xmlns="http://www.w3.org/2000/svg">
                 <path d="M50 0C77.6142 0 100 22.3858 100 50C100 61.3433 96.2208 71.8028 89.8551 80.1921C88.7019 81.7119 88 83.5416 88 85.4493V101.063C88 102.474 86.5797 103.441 85.2675 102.924L71.6374 97.5595C69.7337 96.8102 67.6244 96.8462 65.6818 97.4878C60.7495 99.1166 55.4781 100 50 100C22.3858 100 0 77.6142 0 50C0 22.3858 22.3858 0 50 0Z" fill="#ffffff"/>
               </svg>
               <Pill size={44} className="text-[#5b74f5] relative z-20 mb-1" />
             </div>
          </div>
          {/* ============================================== */}

          {/* Centered text + chat bar */}
          <div className="absolute inset-0 flex flex-col items-center justify-center text-center px-8 pb-10 z-20">
          <p className="text-white/75 text-base mb-2 [text-shadow:0_1px_6px_rgba(0,0,0,0.4)]">{dayName}</p>
          <h1 className="text-white mb-2 text-[clamp(2rem,5vw,3.75rem)] font-bold leading-[1.1] [text-shadow:0_2px_20px_rgba(0,0,0,0.45)]">
            {greeting}!
          </h1>
          <p className="text-white/85 mb-10 text-[clamp(1rem,2.2vw,1.35rem)] [text-shadow:0_1px_10px_rgba(0,0,0,0.35)]">
            Selamat datang di SehatSetara
          </p>

          {/* Gemini-style chat bar */}
          <div className="w-full max-w-2xl">
            <div
              className="flex items-center gap-3 rounded-full px-3 py-2.5 bg-[rgba(237,242,253,0.30)] backdrop-blur-xl border border-[#FFFFFF2E] shadow-[0_4px_32px_rgba(0,0,0,0.2)]"
            >
              {/* Text input */}
              <input
                type="text"
                className="chat-bar-input flex-1 bg-transparent outline-none text-white text-sm pl-2"
                style={{ caretColor: "#7a9bf8" }}
                placeholder={isListening ? "Mendengarkan..." : "Ketik pertanyaan kesehatan..."}
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter" && chatInput.trim()) submitChat(); }}
              />

              {/* Mic / send button */}
              {chatInput.trim() ? (
                <button
                  onClick={submitChat}
                  className="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 transition-all"
                  style={{ background: "linear-gradient(135deg, #5b74f5, #7a9bf8)" }}
                >
                  <Send size={16} className="text-white" />
                </button>
              ) : (
                <button
                  onClick={startVoice}
                  className={`w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 transition-colors ${isListening ? "animate-pulse" : ""}`}
                  style={{ background: isListening ? "#f84848" : "rgba(255,255,255,0.12)" }}
                >
                  <Mic size={18} className={isListening ? "text-white" : "text-white/80"} />
                </button>
              )}
            </div>
          </div>
        </div>
        </div>{/* end rounded container */}
      </div>

      {/* ── White content section ── */}
      <div className="bg-white px-8 pb-8 pt-10">

        {/* Top row: emergency + health tip */}
        <div className="grid grid-cols-5 gap-5 mb-5">
          {/* Emergency button + numbers */}
          <div className="col-span-2 flex flex-col gap-4">
            <button
              onClick={() => onNavigate("medical", "p3k")}
              className="w-full rounded-3xl p-5 flex items-center gap-4 text-left transition-transform active:scale-[0.98] shadow-md"
              style={{ background: "linear-gradient(135deg, #f84848 0%, #ff7070 100%)" }}
            >
              <div className="w-14 h-14 bg-white/20 rounded-2xl flex items-center justify-center flex-shrink-0">
                <AlertCircle size={30} className="text-white" />
              </div>
              <div className="flex-1">
                <div className="text-white font-bold text-xl leading-tight">Darurat & P3K</div>
                <div className="text-white/80 text-sm mt-1">Panduan pertolongan pertama dalam 1 klik</div>
              </div>
              <ChevronRight size={22} className="text-white/70 flex-shrink-0" />
            </button>

            <div className="bg-white rounded-3xl p-5 shadow-sm border border-blue-50">
              <div className="flex items-center gap-2 mb-3">
                <Heart size={15} className="text-[#f84848]" />
                <span className="text-[#1a2560] text-sm font-semibold">Nomor Darurat</span>
              </div>
              <div className="space-y-2">
                {emergencyNumbers.map((e) => {
                  const EIcon = e.icon;
                  return (
                    <a key={e.number} href={`tel:${e.number}`}
                      className={`flex items-center gap-3 border rounded-2xl px-3 py-2.5 ${e.color} transition-opacity active:opacity-70`}>
                      <EIcon size={18} className={`${e.text} flex-shrink-0`} />
                      <span className="text-[#1a2560] text-sm flex-1">{e.name}</span>
                      <span className={`font-bold text-lg ${e.text}`}>{e.number}</span>
                    </a>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Health tip */}
          <div className="col-span-3">
            <div className="rounded-3xl p-6 shadow-sm border border-blue-50 h-full flex flex-col" style={{ background: "linear-gradient(180deg, #ffffff 0%, #edf2fd 100%)" }}>
              <div className="flex items-center gap-2 mb-4">
                <Sun size={16} className="text-amber-500" />
                <span className="text-[#6b7ab8] text-sm font-semibold">Tips Kesehatan Hari Ini</span>
              </div>
              <div className="flex gap-5 flex-1">
                <div className="w-16 h-16 rounded-2xl bg-amber-50 border border-amber-100 flex items-center justify-center flex-shrink-0">
                  <TipIcon size={28} className="text-amber-500" />
                </div>
                <div>
                  <h3 className="text-[#1a2560] text-lg mb-2">{todayTip.title}</h3>
                  <p className="text-[#6b7ab8] text-sm leading-relaxed">{todayTip.desc}</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="mb-5">
          <h2 className="text-[#1a2560] text-lg mb-3">Akses Cepat</h2>
          <div className="grid grid-cols-4 gap-4">
            {quickActions.map((action, i) => {
              const Icon = action.icon;
              return (
                <button key={i} onClick={() => onNavigate(action.screen, action.tab)}
                  className="bg-white rounded-3xl p-5 flex flex-col items-start gap-3 shadow-sm border border-blue-50 text-left active:scale-[0.97] transition-transform hover:shadow-md hover:border-blue-100">
                  <div className="w-12 h-12 rounded-2xl bg-[#edf2fd] flex items-center justify-center">
                    <Icon size={22} className="text-[#5b74f5]" />
                  </div>
                  <div>
                    <div className="text-[#1a2560] text-sm font-semibold">{action.label}</div>
                    <div className="text-[#6b7ab8] text-xs mt-0.5">{action.sublabel}</div>
                  </div>
                  <div className="mt-auto flex items-center gap-1 text-xs font-medium rounded-full px-2 py-0.5"
                    style={{ background: "#edf2fd", color: "#5b74f5" }}>
                    Buka <ChevronRight size={11} />
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Stats */}
        <div className="mt-2">
          <div 
            className="rounded-3xl p-6 border border-blue-50 shadow-sm" 
            style={{ background: "linear-gradient(135deg, #ffffff 0%, #dbeafe 100%)" }}
          >
            <div className="grid grid-cols-4 gap-4 divide-x divide-blue-200/60">
              {stats.map((s, i) => {
                const Icon = s.icon;
                return (
                  <div 
                    key={s.label} 
                    className={`flex flex-col items-center text-center px-2 ${i === 0 ? "pl-0" : ""} ${i === 3 ? "pr-0" : ""}`}
                  >
                    <div className="w-12 h-12 rounded-2xl bg-white/70 shadow-sm border border-white flex items-center justify-center mb-3">
                      <Icon size={22} className="text-[#5b74f5]" />
                    </div>
                    <div className="text-[#1a2560] font-bold text-2xl leading-tight">{s.value}</div>
                    <div className="text-[#6b7ab8] text-xs font-semibold mt-1">{s.label}</div>
                    <div className="text-[#5b74f5] text-[10px] font-medium mt-0.5">{s.sub}</div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}