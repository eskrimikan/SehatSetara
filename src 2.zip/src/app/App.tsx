import { useState, useEffect, useRef } from "react";
import { Home, BookOpen, MapPin, Activity, Mic, Stethoscope } from "lucide-react";
import HomeScreen, { type Screen } from "./components/HomeScreen";
import MedicalInfoScreen from "./components/MedicalInfoScreen";
import FaskesScreen from "./components/FaskesScreen";
import LifestyleScreen from "./components/LifestyleScreen";
import VoiceQAScreen from "./components/VoiceQAScreen";

type MedTab = "penyakit" | "p3k" | "obat";

const navItems: { id: Screen; icon: typeof Home; label: string }[] = [
  { id: "home",      icon: Home,     label: "Beranda"   },
  { id: "medical",   icon: BookOpen, label: "Info"      },
  { id: "faskes",    icon: MapPin,   label: "Faskes"    },
  { id: "lifestyle", icon: Activity, label: "Lifestyle" },
  { id: "qa",        icon: Mic,      label: "Tanya"     },
];

export default function App() {
  const [screen, setScreen] = useState<Screen>("home");
  const [medTab, setMedTab] = useState<MedTab>("penyakit");
  const [qaQuery, setQaQuery] = useState<string>("");
  const [scrollY, setScrollY] = useState(0);
  const mainRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = mainRef.current;
    if (!el) return;
    const handler = () => setScrollY(el.scrollTop);
    el.addEventListener("scroll", handler, { passive: true });
    return () => el.removeEventListener("scroll", handler);
  }, []);

  useEffect(() => {
    if (mainRef.current) mainRef.current.scrollTop = 0;
    setScrollY(0);
  }, [screen]);

  const navigate = (s: Screen, payload?: string) => {
    setScreen(s);
    if (s === "medical" && payload) setMedTab(payload as MedTab);
    if (s === "qa" && payload) setQaQuery(payload);
  };

  const progress = screen === "home" ? Math.min(scrollY / 160, 1) : 1;

  const navBg = progress < 0.05
    ? "rgba(255,255,255,0.12)"
    : `rgba(255,255,255,${0.55 + 0.40 * progress})`;

  const navShadow = progress < 0.1
    ? `inset 0 0 0 1px rgba(255,255,255,${0.25 * (1 - progress)})`
    : `0 4px 24px rgba(91,116,245,${0.10 + 0.12 * progress}), inset 0 0 0 1px rgba(91,116,245,0.10)`;

  const labelColor = progress > 0.5 ? "#1a2560" : "rgba(255,255,255,0.9)";
  const logoColor  = progress > 0.5 ? "#5b74f5" : "rgba(255,255,255,0.9)";

  return (
    <div className="size-full flex flex-col" style={{ background: "#f0f5ff" }}>
      {/* ── Navbar ── */}
      <header className="fixed top-0 left-0 right-0 z-50 px-3 py-3 sm:px-5 sm:py-4" style={{ pointerEvents: "none" }}>
        <div
          className="flex items-center h-11 sm:h-12"
          style={{
            background: navBg,
            backdropFilter: "blur(24px)",
            WebkitBackdropFilter: "blur(24px)",
            borderRadius: "9999px",
            boxShadow: navShadow,
            transition: "background 0.4s ease, box-shadow 0.4s ease",
            padding: "0 4px 0 14px",
            pointerEvents: "auto",
          }}
        >
          {/* Logo */}
          <div className="flex items-center gap-1.5 flex-shrink-0">
            <div className="w-6 h-6 sm:w-7 sm:h-7 rounded-full flex items-center justify-center"
              style={{ background: progress > 0.5 ? "linear-gradient(135deg,#5b74f5,#7a9bf8)" : "rgba(255,255,255,0.22)" }}>
              <Stethoscope size={12} style={{ color: progress > 0.5 ? "#fff" : "rgba(255,255,255,0.95)" }} />
            </div>
            <span className="font-bold text-xs sm:text-sm tracking-tight transition-colors duration-300" style={{ color: logoColor }}>
              SehatSetara
            </span>
          </div>

          <div className="flex-1" />

          {/* Nav tabs */}
          <nav className="flex items-center gap-0">
            {navItems.map(({ id, icon: Icon, label }) => {
              const active = screen === id;
              return (
                <button
                  key={id}
                  onClick={() => navigate(id)}
                  className="flex flex-col sm:flex-row items-center gap-0.5 sm:gap-1.5 px-2 sm:px-3.5 py-1 sm:py-1.5 rounded-full text-[10px] sm:text-sm font-medium transition-all duration-200"
                  style={
                    active
                      ? {
                          background: progress > 0.5
                            ? "linear-gradient(135deg,#5b74f5,#7a9bf8)"
                            : "rgba(255,255,255,0.25)",
                          color: "#fff",
                          boxShadow: progress > 0.5 ? "0 2px 12px rgba(91,116,245,0.35)" : "none",
                        }
                      : { color: labelColor }
                  }
                >
                  {/* Show icon only on mobile, icon+label on desktop */}
                  <Icon size={14} className="sm:hidden" />
                  <span className="hidden sm:inline">{label}</span>
                  <span className="sm:hidden leading-none">{label}</span>
                </button>
              );
            })}
          </nav>
        </div>
      </header>

      {/* ── Content ── */}
      <main ref={mainRef} className="flex-1 overflow-y-auto min-h-0">
        {screen === "home" && <HomeScreen onNavigate={navigate} />}
        {screen !== "home" && (
          <div className="h-full flex flex-col pt-14 sm:pt-16">
            {screen === "medical"   && <MedicalInfoScreen initialTab={medTab} />}
            {screen === "faskes"    && <FaskesScreen />}
            {screen === "lifestyle" && <LifestyleScreen />}
            {screen === "qa"        && <VoiceQAScreen initialQuery={qaQuery} clearQuery={() => setQaQuery("")} />}
          </div>
        )}
      </main>
    </div>
  );
}