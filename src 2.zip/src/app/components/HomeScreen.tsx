import { useState, useRef } from "react";
import {
  AlertCircle, MapPin, Activity, Mic, ChevronRight, Sun,
  Heart, ClipboardList, Bandage, Pill, Building2,
  Leaf, Droplets, Moon, Flame, Shield, Send,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import heroImg from "../../imports/image-5.png";

export type Screen = "home" | "medical" | "faskes" | "lifestyle" | "qa";

interface Props {
  onNavigate: (screen: Screen, tab?: string) => void;
}

interface HealthTip {
  icon: LucideIcon;
  title: string;
  desc: string;
}

const healthTips: HealthTip[] = [
  { icon: Droplets, title: "Cuci Tangan 6 Langkah",         desc: "Cuci tangan dengan sabun minimal 20 detik dapat mencegah 80% penyakit menular umum." },
  { icon: Droplets, title: "Minum 8 Gelas Air Sehari",       desc: "Konsumsi 2 liter air putih per hari menjaga fungsi ginjal, kulit, dan konsentrasi Anda." },
  { icon: Leaf,     title: "Makan Sayur & Buah Setiap Hari", desc: "Setengah piring sayur dan buah memenuhi kebutuhan vitamin, mineral, dan serat harian." },
  { icon: Moon,     title: "Tidur 7–8 Jam Per Malam",        desc: "Tidur cukup meningkatkan imunitas dan membantu tubuh memperbaiki sel-sel yang rusak." },
  { icon: Activity, title: "Aktif Bergerak 30 Menit",         desc: "Jalan kaki 30 menit per hari menurunkan risiko penyakit jantung, diabetes, dan depresi." },
];

const todayTip = healthTips[new Date().getDay() % healthTips.length];

const emergencyNumbers = [
  { name: "Ambulans / IGD",    number: "119", icon: AlertCircle, color: "bg-[#fff5f5] border-[#ffdcdc]", text: "text-[#f84848]" },
  { name: "Pemadam Kebakaran", number: "113", icon: Flame,       color: "bg-[#fff7f0] border-[#ffe5cc]", text: "text-orange-500" },
  { name: "Polisi",             number: "110", icon: Shield,      color: "bg-[#f0f4ff] border-[#d0dbfd]", text: "text-[#5b74f5]" },
];

const quickActions = [
  { screen: "medical"   as Screen, tab: "penyakit", icon: ClipboardList, label: "Info Penyakit",       sublabel: "10+ panduan lengkap"  },
  { screen: "medical"   as Screen, tab: "p3k",      icon: Bandage,       label: "Pertolongan Pertama", sublabel: "Panduan darurat cepat" },
  { screen: "faskes"    as Screen, tab: undefined,  icon: MapPin,        label: "Faskes Terdekat",     sublabel: "Peta & kontak"         },
  { screen: "lifestyle" as Screen, tab: undefined,  icon: Leaf,          label: "Gaya Hidup",          sublabel: "Lacak kebiasaanmu"     },
];

const stats = [
  { label: "Penyakit",   value: "10+", sub: "Terdokumentasi",  icon: ClipboardList },
  { label: "Panduan P3K", value: "8",  sub: "Terstruktur",      icon: Bandage       },
  { label: "Obat-obatan", value: "10", sub: "Dosis lengkap",    icon: Pill          },
  { label: "Faskes",      value: "7",  sub: "Peta & kontak",    icon: Building2     },
];

export default function HomeScreen({ onNavigate }: Props) {
  const [chatInput, setChatInput] = useState("");
  const [isListening, setIsListening] = useState(false);
  const recogRef = useRef<any>(null);

  const now      = new Date();
  const hour     = now.getHours();
  const greeting = hour < 12 ? "Selamat Pagi" : hour < 17 ? "Selamat Siang" : "Selamat Malam";
  const dayName  = now.toLocaleDateString("id-ID", { weekday: "long", day: "numeric", month: "long", year: "numeric" });
  const TipIcon  = todayTip.icon;

  const submitChat = () => {
    if (chatInput.trim()) { onNavigate("qa", chatInput.trim()); setChatInput(""); }
    else { onNavigate("qa"); }
  };

  const startVoice = () => {
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SR) { alert("Browser Anda tidak mendukung fitur pengenalan suara. Gunakan Chrome atau Safari terbaru."); return; }
    if (isListening) { recogRef.current?.stop(); setIsListening(false); return; }
    const r = new SR();
    r.lang = "id-ID"; r.continuous = false; r.interimResults = false;
    r.onstart  = () => setIsListening(true);
    r.onresult = (e: any) => { setChatInput(e.results[0][0].transcript); };
    r.onend    = () => setIsListening(false);
    r.onerror  = () => setIsListening(false);
    r.start(); recogRef.current = r;
  };

  return (
    <div className="min-h-full" style={{ background: "linear-gradient(160deg,#eef3fd 0%,#f5f8ff 40%,#e8f0fd 100%)" }}>
      <style>{`
        @keyframes float-slow {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-15px); }
        }
        @keyframes float-delay {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-12px); }
        }
        .animate-float-1 { animation: float-slow 4s ease-in-out infinite; }
        .animate-float-2 { animation: float-delay 5s ease-in-out infinite; animation-delay: 2s; }

        @keyframes gradient-shift {
          0%   { background-position: 0% 50%; }
          50%  { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
        @keyframes text-gradient-shift {
          0%   { background-position: 0% 50%; }
          50%  { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
        .greeting-gradient {
          background: linear-gradient(90deg, #ffffff, #ddeeff, #ffffff, #e8f4ff, #ffffff);
          background-size: 300% 300%;
          animation: text-gradient-shift 5s ease infinite;
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
        }
        .tip-card-gradient {
          background: linear-gradient(135deg, #fffdf0, #ffffff, #fefce8, #ffffff, #fffdf0);
          background-size: 300% 300%;
          animation: gradient-shift 6s ease infinite;
        }
        .card-lift {
          transition: transform 0.2s ease, box-shadow 0.2s ease;
        }
        .card-lift:hover {
          transform: translateY(-2px);
          box-shadow: 0 8px 30px rgba(91,116,245,0.12);
        }
      `}</style>

      {/* ── HERO ── */}
      {/* Mobile: shorter hero, desktop: taller */}
      <div className="w-full pt-4 px-4 pb-4 box-border h-[751px]">
        <div className="relative w-full h-[725px] rounded-3xl overflow-hidden flex items-center justify-center">

          <img src={heroImg} alt=""
            className="absolute inset-0 w-full h-full object-cover object-center" />

          {/* Bottom gradient overlay */}
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#edf2fd80] via-50% to-[#5b74f5]" />

          {/* Bubble 1: Heart — hidden on small mobile, visible sm+ */}
          <div className="absolute top-[22%] left-[8%] sm:left-[12%] animate-float-1 z-10 hidden sm:block">
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 bg-white/20 blur-3xl rounded-full" />
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-[calc(50%+2px)] w-[110px] h-[110px] bg-white/10 border border-white/20 rounded-full backdrop-blur-md" />
            <div className="relative z-10 w-[80px] h-[84px] flex items-center justify-center" style={{ filter: "drop-shadow(0 10px 15px rgba(0,0,0,0.12))" }}>
              <svg className="absolute inset-0 w-full h-full -scale-x-100" viewBox="0 0 100 104" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M50 0C77.6142 0 100 22.3858 100 50C100 61.3433 96.2208 71.8028 89.8551 80.1921C88.7019 81.7119 88 83.5416 88 85.4493V101.063C88 102.474 86.5797 103.441 85.2675 102.924L71.6374 97.5595C69.7337 96.8102 67.6244 96.8462 65.6818 97.4878C60.7495 99.1166 55.4781 100 50 100C22.3858 100 0 77.6142 0 50C0 22.3858 22.3858 0 50 0Z" fill="#ffffff"/>
              </svg>
              <Heart size={32} className="text-[#f84848] relative z-20 mb-1" />
            </div>
          </div>

          {/* Bubble 2: Pill */}
          <div className="absolute top-[67%] right-[8%] sm:right-[12%] animate-float-2 z-10 hidden sm:block">
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-56 h-56 bg-white/15 blur-3xl rounded-full" />
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-[calc(50%+2px)] w-[130px] h-[130px] bg-white/10 border border-white/20 rounded-full backdrop-blur-md" />
            <div className="relative z-10 w-[100px] h-[104px] flex items-center justify-center" style={{ filter: "drop-shadow(0 12px 20px rgba(0,0,0,0.15))" }}>
              <svg className="absolute inset-0 w-full h-full" viewBox="0 0 100 104" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M50 0C77.6142 0 100 22.3858 100 50C100 61.3433 96.2208 71.8028 89.8551 80.1921C88.7019 81.7119 88 83.5416 88 85.4493V101.063C88 102.474 86.5797 103.441 85.2675 102.924L71.6374 97.5595C69.7337 96.8102 67.6244 96.8462 65.6818 97.4878C60.7495 99.1166 55.4781 100 50 100C22.3858 100 0 77.6142 0 50C0 22.3858 22.3858 0 50 0Z" fill="#ffffff"/>
              </svg>
              <Pill size={44} className="text-[#5b74f5] relative z-20 mb-1" />
            </div>
          </div>

          {/* Text + chat */}
          <div className="absolute inset-0 flex flex-col items-center justify-center text-center px-5 sm:px-8 pb-8 sm:pb-10 z-20">
            <p className="text-white/75 text-xs sm:text-base mb-1.5 sm:mb-2 [text-shadow:0_1px_6px_rgba(0,0,0,0.4)]">
              {dayName}
            </p>
            <h1 className="greeting-gradient mb-1.5 sm:mb-2 font-bold leading-[1.1]"
              style={{ fontSize: "clamp(1.75rem, 6vw, 3.75rem)" }}>
              {greeting}!
            </h1>
            <p className="text-white/85 mb-6 sm:mb-10 [text-shadow:0_1px_10px_rgba(0,0,0,0.35)]"
              style={{ fontSize: "clamp(0.875rem, 2.5vw, 1.35rem)" }}>
              Selamat datang di SehatSetara
            </p>

            {/* Chat bar */}
            <div className="w-full max-w-xs sm:max-w-2xl">
              <div className="flex items-center gap-2 sm:gap-3 rounded-full px-3 py-2 sm:py-2.5 bg-[rgba(237,242,253,0.30)] backdrop-blur-xl border border-[#FFFFFF2E] shadow-[0_4px_32px_rgba(0,0,0,0.2)]">
                <input
                  type="text"
                  className="chat-bar-input flex-1 bg-transparent outline-none text-white text-xs sm:text-sm pl-1 sm:pl-2"
                  style={{ caretColor: "#7a9bf8" }}
                  placeholder={isListening ? "Mendengarkan..." : "Ketik pertanyaan kesehatan..."}
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  onKeyDown={(e) => { if (e.key === "Enter" && chatInput.trim()) submitChat(); }}
                />
                {chatInput.trim() ? (
                  <button onClick={submitChat}
                    className="w-8 h-8 sm:w-9 sm:h-9 rounded-full flex items-center justify-center flex-shrink-0 transition-all"
                    style={{ background: "linear-gradient(135deg, #5b74f5, #7a9bf8)" }}>
                    <Send size={14} className="text-white" />
                  </button>
                ) : (
                  <button onClick={startVoice}
                    className={`w-8 h-8 sm:w-9 sm:h-9 rounded-full flex items-center justify-center flex-shrink-0 transition-colors ${isListening ? "animate-pulse" : ""}`}
                    style={{ background: isListening ? "#f84848" : "rgba(255,255,255,0.12)" }}>
                    <Mic size={15} className={isListening ? "text-white" : "text-white/80"} />
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ── CONTENT ── */}
      <div className="px-3 sm:px-5 pb-8 pt-2">

        {/* Emergency + Health Tip */}
        {/* Mobile: stacked, Desktop: side by side 2/5 + 3/5 */}
        <div className="flex flex-col sm:grid sm:grid-cols-5 gap-3 sm:gap-4 mb-3 sm:mb-4">

          {/* Emergency */}
          <div className="sm:col-span-2 flex flex-col gap-3">
            <button
              onClick={() => onNavigate("medical", "p3k")}
              className="w-full rounded-[18px] sm:rounded-[20px] p-3.5 sm:p-4 flex items-center gap-3 text-left card-lift"
              style={{ background: "linear-gradient(135deg, #f84848 0%, #fc7373 100%)", boxShadow: "0 4px 20px rgba(248,72,72,0.28)" }}
            >
              <div className="w-10 h-10 sm:w-12 sm:h-12 bg-white/20 rounded-[12px] sm:rounded-[14px] flex items-center justify-center flex-shrink-0">
                <AlertCircle size={22} className="text-white" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-white font-bold text-sm sm:text-base leading-tight">Darurat & P3K</div>
                <div className="text-white/75 text-xs mt-0.5 leading-snug">Panduan pertolongan pertama cepat</div>
              </div>
              <ChevronRight size={16} className="text-white/70 flex-shrink-0" />
            </button>

            <div className="rounded-[18px] sm:rounded-[20px] p-3.5 sm:p-4"
              style={{ background: "rgba(255,255,255,0.80)", backdropFilter: "blur(12px)", border: "1px solid rgba(91,116,245,0.08)", boxShadow: "0 2px 16px rgba(91,116,245,0.06)" }}>
              <div className="flex items-center gap-1.5 mb-2.5">
                <Heart size={12} className="text-[#f84848]" />
                <span className="text-[#1a2560] text-xs font-semibold">Nomor Darurat</span>
              </div>
              <div className="space-y-1.5 sm:space-y-2">
                {emergencyNumbers.map((e) => {
                  const EIcon = e.icon;
                  return (
                    <a key={e.number} href={`tel:${e.number}`}
                      className={`flex items-center gap-2 sm:gap-2.5 border rounded-[10px] sm:rounded-[12px] px-2.5 sm:px-3 py-2 ${e.color} transition-opacity active:opacity-70`}>
                      <EIcon size={14} className={`${e.text} flex-shrink-0`} />
                      <span className="text-[#1a2560] text-xs flex-1">{e.name}</span>
                      <span className={`font-bold text-sm sm:text-base ${e.text}`}>{e.number}</span>
                    </a>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Health Tip */}
          <div className="sm:col-span-3">
            <div className="tip-card-gradient rounded-[18px] sm:rounded-[20px] p-4 sm:p-5 h-full flex flex-col"
              style={{ border: "1px solid rgba(251,191,36,0.15)", boxShadow: "0 2px 20px rgba(251,191,36,0.08)" }}>
              <div className="flex items-center gap-2 mb-3 sm:mb-4">
                <Sun size={14} className="text-amber-500" />
                <span className="text-[#6b7ab8] text-xs font-semibold tracking-wide uppercase">Tips Kesehatan Hari Ini</span>
              </div>
              <div className="flex gap-3 sm:gap-4 flex-1">
                <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-[12px] sm:rounded-[14px] flex items-center justify-center flex-shrink-0"
                  style={{ background: "linear-gradient(135deg, #fff8e1, #fef3c7)", border: "1px solid rgba(251,191,36,0.20)" }}>
                  <TipIcon size={22} className="text-amber-500" />
                </div>
                <div>
                  <h3 className="text-[#1a2560] text-sm sm:text-base font-semibold mb-1 sm:mb-1.5 leading-snug">{todayTip.title}</h3>
                  <p className="text-[#6b7ab8] text-xs sm:text-sm leading-relaxed">{todayTip.desc}</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        {/* Mobile: 2x2 grid, Desktop: 4 cols */}
        <div className="mb-3 sm:mb-4">
          <h2 className="text-[#1a2560] text-sm sm:text-base font-semibold mb-2.5 sm:mb-3 px-0.5">Akses Cepat</h2>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 sm:gap-3">
            {quickActions.map((action, i) => {
              const Icon = action.icon;
              return (
                <button key={i} onClick={() => onNavigate(action.screen, action.tab)}
                  className="rounded-[18px] sm:rounded-[20px] p-3.5 sm:p-4 flex flex-col items-start gap-2.5 sm:gap-3 text-left card-lift"
                  style={{ background: "rgba(255,255,255,0.85)", backdropFilter: "blur(12px)", border: "1px solid rgba(91,116,245,0.08)", boxShadow: "0 2px 12px rgba(91,116,245,0.06)" }}>
                  <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-[12px] sm:rounded-[13px] flex items-center justify-center"
                    style={{ background: "linear-gradient(135deg, #eef2ff, #dde8fd)" }}>
                    <Icon size={18} style={{ color: "#5b74f5" }} />
                  </div>
                  <div>
                    <div className="text-[#1a2560] text-xs sm:text-sm font-semibold leading-snug">{action.label}</div>
                    <div className="text-[#6b7ab8] text-[10px] sm:text-xs mt-0.5">{action.sublabel}</div>
                  </div>
                  <div className="mt-auto flex items-center gap-1 text-[10px] sm:text-xs font-semibold rounded-full px-2 sm:px-2.5 py-0.5 sm:py-1"
                    style={{ background: "linear-gradient(135deg,#eef2ff,#dde8fd)", color: "#5b74f5" }}>
                    Buka <ChevronRight size={10} />
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Stats */}
        {/* Mobile: 2x2 grid, Desktop: 4 cols with dividers */}
        <div className="rounded-[20px] sm:rounded-[24px] p-4 sm:p-5"
          style={{ background: "linear-gradient(135deg, rgba(255,255,255,0.90) 0%, rgba(220,233,252,0.75) 100%)", backdropFilter: "blur(16px)", border: "1px solid rgba(91,116,245,0.10)", boxShadow: "0 4px 24px rgba(91,116,245,0.08)" }}>

          {/* Mobile layout: 2x2 */}
          <div className="grid grid-cols-2 gap-3 sm:hidden">
            {stats.map((s) => {
              const Icon = s.icon;
              return (
                <div key={s.label} className="flex flex-col items-center text-center">
                  <div className="w-10 h-10 rounded-[12px] flex items-center justify-center mb-2"
                    style={{ background: "rgba(255,255,255,0.85)", border: "1px solid rgba(91,116,245,0.10)", boxShadow: "0 2px 8px rgba(91,116,245,0.08)" }}>
                    <Icon size={18} style={{ color: "#5b74f5" }} />
                  </div>
                  <div className="text-[#1a2560] font-bold text-xl leading-tight">{s.value}</div>
                  <div className="text-[#6b7ab8] text-[10px] font-semibold mt-0.5 leading-snug">{s.label}</div>
                  <div className="text-[#5b74f5] text-[9px] font-medium mt-0.5">{s.sub}</div>
                </div>
              );
            })}
          </div>

          {/* Desktop layout: 4 cols with dividers */}
          <div className="hidden sm:grid grid-cols-4 gap-4 divide-x divide-blue-200/50">
            {stats.map((s, i) => {
              const Icon = s.icon;
              return (
                <div key={s.label}
                  className={`flex flex-col items-center text-center px-3 ${i === 0 ? "pl-0" : ""} ${i === 3 ? "pr-0" : ""}`}>
                  <div className="w-11 h-11 rounded-[13px] flex items-center justify-center mb-2.5"
                    style={{ background: "rgba(255,255,255,0.85)", border: "1px solid rgba(91,116,245,0.10)", boxShadow: "0 2px 8px rgba(91,116,245,0.08)" }}>
                    <Icon size={20} style={{ color: "#5b74f5" }} />
                  </div>
                  <div className="text-[#1a2560] font-bold text-2xl leading-tight">{s.value}</div>
                  <div className="text-[#6b7ab8] text-[11px] font-semibold mt-1 leading-snug">{s.label}</div>
                  <div className="text-[#5b74f5] text-[10px] font-medium mt-0.5">{s.sub}</div>
                </div>
              );
            })}
          </div>
        </div>

      </div>
    </div>
  );
}