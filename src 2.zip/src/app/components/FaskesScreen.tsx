import { useState } from "react";
import { MapPin, Phone, Clock, Navigation, X, Building2, Stethoscope, Pill, Baby, Cross } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { facilities, type Facility, type FacilityType } from "./data/medicalData";

const typeConfig: Record<FacilityType, { label: string; color: string; bg: string; dot: string; icon: LucideIcon }> = {
  puskesmas: { label: "Puskesmas",      color: "text-emerald-700", bg: "bg-emerald-50 border-emerald-200", dot: "bg-emerald-500",  icon: Building2    },
  klinik:    { label: "Klinik",         color: "text-[#5b74f5]",   bg: "bg-[#edf2fd] border-blue-200",    dot: "bg-[#5b74f5]",   icon: Stethoscope  },
  apotek:    { label: "Apotek",         color: "text-violet-700",  bg: "bg-violet-50 border-violet-200",  dot: "bg-violet-500",   icon: Pill         },
  bidan:     { label: "Bidan/Posyandu", color: "text-pink-700",    bg: "bg-pink-50 border-pink-200",      dot: "bg-pink-500",     icon: Baby         },
  rs:        { label: "Rumah Sakit",    color: "text-[#f84848]",   bg: "bg-red-50 border-red-200",        dot: "bg-[#f84848]",   icon: Cross        },
};

const filterOptions: { id: FacilityType | "all"; label: string }[] = [
  { id: "all",       label: "Semua"     },
  { id: "puskesmas", label: "Puskesmas" },
  { id: "klinik",    label: "Klinik"    },
  { id: "apotek",    label: "Apotek"    },
  { id: "bidan",     label: "Bidan"     },
  { id: "rs",        label: "RS"        },
];

// FUNGSI BARU: Untuk mengecek apakah faskes sedang buka berdasarkan jam saat ini
const checkIsComponentOpen = (operationalHours?: string): boolean => {
  if (!operationalHours) return true;
  try {
    const hoursStr = operationalHours.toLowerCase();
    
    // Kalau ada tulisan 24 jam, pasti buka
    if (hoursStr.includes("24 jam")) return true;
    
    // Regex pintar: Cari pola dua pasang angka jam (contoh: 08:00-21:00 atau 07:30–14:00)
    // Walaupun depannya ada tulisan "Sen-Jum", dia cuma akan ambil angka jamnya saja.
    const timeMatch = hoursStr.match(/(\d{2}:\d{2})\s*[-–]\s*(\d{2}:\d{2})/);
    
    // Kalau format angkanya gak ketemu sama sekali, fallback ke true
    if (!timeMatch) return true; 
    
    const openTime = timeMatch[1];  // Hasil: "08:00"
    const closeTime = timeMatch[2]; // Hasil: "21:00"
    
    const [openHour, openMin] = openTime.split(":").map(Number);
    const [closeHour, closeMin] = closeTime.split(":").map(Number);
    
    const now = new Date();
    const currentHour = now.getHours();
    const currentMin = now.getMinutes();
    
    const nowInMinutes = currentHour * 60 + currentMin;
    const openInMinutes = openHour * 60 + (openMin || 0);
    const closeInMinutes = closeHour * 60 + (closeMin || 0);
    
    // Jika faskes melewati tengah malam (misal buka jam 20:00 - tutup jam 02:00 pagi)
    if (closeInMinutes < openInMinutes) {
       return nowInMinutes >= openInMinutes || nowInMinutes <= closeInMinutes;
    }

    // Cek apakah waktu saat ini berada di antara jam buka dan jam tutup
    return nowInMinutes >= openInMinutes && nowInMinutes <= closeInMinutes;
  } catch (e) {
    return true; // fallback default kalau ada error tak terduga
  }
};

export default function FaskesScreen() {
  const [activeFilter, setActiveFilter] = useState<FacilityType | "all">("all");
  const [selected, setSelected] = useState<Facility | null>(facilities[0]);

  const filtered = facilities
    .filter((f) => activeFilter === "all" || f.type === activeFilter)
    .sort((a, b) => a.distance - b.distance);

  return (
    <div className="h-full flex flex-col p-8">
      <div className="mb-5 flex-shrink-0">
        <h1 className="text-[#1a2560] text-3xl mb-1">Radar Faskes</h1>
        <p className="text-[#6b7ab8] text-sm">Fasilitas kesehatan di sekitar lokasi Anda</p>
      </div>

      {/* Filter chips */}
      <div className="flex gap-2 mb-5 flex-shrink-0 flex-wrap">
        {filterOptions.map((opt) => {
          const cfg = opt.id !== "all" ? typeConfig[opt.id as FacilityType] : null;
          const Icon = cfg?.icon;
          return (
            <button key={opt.id} onClick={() => setActiveFilter(opt.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-2xl text-sm font-medium transition-all ${
                activeFilter === opt.id ? "text-white shadow-md" : "bg-white text-[#6b7ab8] border border-blue-100"
              }`}
              style={activeFilter === opt.id ? { background: "linear-gradient(135deg, #5b74f5, #7a9bf8)" } : {}}>
              {Icon ? <Icon size={14} /> : <MapPin size={14} />}
              {opt.label}
            </button>
          );
        })}
      </div>

      {/* Content */}
      <div className="flex gap-5 flex-1 min-h-0">
        {/* List */}
        <div className="w-80 flex-shrink-0 bg-white rounded-3xl border border-blue-50 shadow-sm overflow-y-auto">
          <div className="px-4 py-3 border-b border-blue-50 flex-shrink-0">
            <span className="text-[#6b7ab8] text-xs">{filtered.length} fasilitas ditemukan</span>
          </div>
          {filtered.map((f) => {
            const cfg = typeConfig[f.type];
            const Icon = cfg.icon;
            
            // Cek real-time buka/tutup di daftar kiri
            const isOpenNow = checkIsComponentOpen(f.hours);
            
            return (
              <button key={f.id} onClick={() => setSelected(f)}
                className={`w-full px-4 py-3.5 flex items-start gap-3 border-b border-blue-50 text-left transition-colors ${selected?.id === f.id ? "bg-[#edf2fd]" : "hover:bg-gray-50"}`}>
                <div className={`w-10 h-10 rounded-xl border ${cfg.bg} flex items-center justify-center flex-shrink-0`}>
                  <Icon size={18} className={cfg.color} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-[#1a2560] text-sm font-medium leading-tight">{f.name}</span>
                    <span className={`text-xs px-1.5 py-0.5 rounded-full font-medium ${isOpenNow ? "bg-emerald-50 text-emerald-700" : "bg-gray-100 text-gray-500"}`}>
                      {isOpenNow ? "Buka" : "Tutup"}
                    </span>
                  </div>
                  <div className="flex items-center gap-1 text-[#6b7ab8] text-xs mt-1">
                    <Navigation size={10} className="flex-shrink-0" />
                    <span>{f.distance} km dari Anda</span>
                  </div>
                  <span className={`text-xs px-1.5 py-0.5 rounded-full mt-1 inline-block border ${cfg.bg} ${cfg.color}`}>{cfg.label}</span>
                </div>
              </button>
            );
          })}
        </div>

        {/* Map + detail */}
        <div className="flex-1 flex flex-col gap-4 min-w-0">
          {/* Map */}
          <div className="relative rounded-3xl overflow-hidden border border-blue-100 flex-1"
            style={{ background: "linear-gradient(135deg, #dce8fc 0%, #edf2fd 100%)", minHeight: 240 }}>
            {[20, 40, 60, 80].map((p) => (
              <div key={`h${p}`} className="absolute w-full border-t border-blue-200 opacity-30" style={{ top: `${p}%` }} />
            ))}
            {[20, 40, 60, 80].map((p) => (
              <div key={`v${p}`} className="absolute h-full border-l border-blue-200 opacity-30" style={{ left: `${p}%` }} />
            ))}
            <div className="absolute bg-white/50 h-2 w-full" style={{ top: "50%", transform: "translateY(-50%)" }} />
            <div className="absolute bg-white/50 w-2 h-full" style={{ left: "50%", transform: "translateX(-50%)" }} />

            {/* User dot */}
            <div className="absolute z-20" style={{ left: "50%", top: "50%", transform: "translate(-50%,-50%)" }}>
              <div className="relative">
                <div className="w-5 h-5 bg-[#5b74f5] rounded-full border-2 border-white shadow-lg z-10 relative" />
                <div className="absolute inset-0 w-5 h-5 bg-[#5b74f5] rounded-full animate-ping opacity-50" />
              </div>
            </div>
            <div className="absolute z-10 text-white text-xs px-2 py-0.5 rounded-full shadow font-medium"
              style={{ left: "50%", top: "calc(50% + 14px)", transform: "translateX(-50%)", background: "#5b74f5" }}>
              Kamu
            </div>

            {/* Facility pins */}
            {facilities.filter((f) => activeFilter === "all" || f.type === activeFilter).map((f) => {
              const cfg = typeConfig[f.type];
              const FIcon = cfg.icon;
              const isSelected = selected?.id === f.id;
              
              // Cek real-time buka/tutup di Peta
              const isOpenNow = checkIsComponentOpen(f.hours);
              
              return (
                <button key={f.id} onClick={() => setSelected(f)}
                  className="absolute z-20 flex flex-col items-center"
                  style={{ left: `${f.lng}%`, top: `${f.lat}%`, transform: "translate(-50%,-100%)" }}>
                  <div className={`w-9 h-9 ${cfg.dot} rounded-full flex items-center justify-center border-2 border-white shadow-md transition-transform ${
                    isSelected ? "scale-125 shadow-lg" : "opacity-80"} ${!isOpenNow ? "opacity-40 grayscale" : ""}`}>
                    <FIcon size={16} className="text-white" />
                  </div>
                  {isSelected && (
                    <div className="absolute top-full mt-1 bg-[#1a2560] text-white rounded-xl px-2 py-1 text-xs font-medium shadow-lg whitespace-nowrap">
                      {f.distance}km — {f.name.split(" ").slice(0, 2).join(" ")}
                    </div>
                  )}
                </button>
              );
            })}

            <div className="absolute bottom-3 right-3 text-xs text-[#6b7ab8] opacity-60">Simulasi Peta</div>
            <div className="absolute bottom-3 left-3 bg-white/80 rounded-xl px-3 py-2 backdrop-blur-sm flex flex-wrap gap-2 max-w-xs">
              {Object.entries(typeConfig).map(([type, cfg]) => {
                const LIcon = cfg.icon;
                return (
                  <div key={type} className="flex items-center gap-1">
                    <div className={`w-2 h-2 rounded-full ${cfg.dot}`} />
                    <LIcon size={10} className={cfg.color} />
                    <span className="text-xs text-[#6b7ab8]">{cfg.label}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Detail card */}
          {selected && (
            <div className="bg-white rounded-3xl border border-blue-50 shadow-sm p-5 flex-shrink-0">
              <div className="flex items-start gap-4">
                <div className={`w-14 h-14 rounded-2xl border ${typeConfig[selected.type].bg} flex items-center justify-center flex-shrink-0`}>
                  {(() => { const Icon = typeConfig[selected.type].icon; return <Icon size={24} className={typeConfig[selected.type].color} />; })()}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-3 flex-wrap">
                    <h2 className="text-[#1a2560] text-lg font-semibold">{selected.name}</h2>
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium border ${typeConfig[selected.type].bg} ${typeConfig[selected.type].color}`}>
                      {typeConfig[selected.type].label}
                    </span>
                    
                    {/* Cek real-time buka/tutup di Detail Card */}
                    {(() => {
                      const isSelectedOpen = checkIsComponentOpen(selected.hours);
                      return (
                        <span className={`text-xs px-2 py-0.5 rounded-full font-medium flex items-center gap-1 ${isSelectedOpen ? "bg-emerald-50 text-emerald-700" : "bg-gray-100 text-gray-500"}`}>
                          <span className={`w-1.5 h-1.5 rounded-full inline-block ${isSelectedOpen ? "bg-emerald-500" : "bg-gray-400"}`} />
                          {isSelectedOpen ? "Sedang Buka" : "Sedang Tutup"}
                        </span>
                      );
                    })()}
                  </div>
                  <div className="grid grid-cols-3 gap-4 mt-3">
                    <div className="flex items-start gap-2">
                      <MapPin size={15} className="text-[#b0bef8] flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="text-[#6b7ab8] text-xs">Alamat</p>
                        <p className="text-[#1a2560] text-sm">{selected.address}</p>
                        <p className="text-[#5b74f5] text-xs font-medium mt-0.5 flex items-center gap-1">
                          <Navigation size={10} /> {selected.distance} km
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-2">
                      <Clock size={15} className="text-[#b0bef8] flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="text-[#6b7ab8] text-xs">Jam Operasional</p>
                        <p className="text-[#1a2560] text-sm">{selected.hours}</p>
                      </div>
                    </div>
                    <a href={`tel:${selected.phone}`}
                      className="flex items-center gap-3 rounded-2xl p-3 text-white transition-opacity active:opacity-80"
                      style={{ background: "linear-gradient(135deg, #5b74f5, #7a9bf8)" }}>
                      <Phone size={18} className="flex-shrink-0" />
                      <div><div className="font-semibold text-sm">Hubungi</div><div className="text-white/80 text-xs">{selected.phone}</div></div>
                    </a>
                  </div>
                </div>
                <button onClick={() => setSelected(null)} className="text-[#b0bef8] hover:text-[#6b7ab8] flex-shrink-0">
                  <X size={18} />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}